package inf1007.simulateur_decodeur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimulateurDecodeurApplicationTests {

    @Test
    void contextLoads() {
    }

}
