package inf1007.simulateur_decodeur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimulateurDecodeurApplication {

    public static void main(String[] args) {

        SpringApplication.run(SimulateurDecodeurApplication.class, args);
    }

}
